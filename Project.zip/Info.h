
#ifndef INFO_H
#define INFO_H

#include <stdlib.h>

typedef struct Info *InfoP;

typedef struct Info{
size_t pos;
size_t size;
}Info;

#endif
